
require("dotenv").config();

const express = require("express");
const { Resend } = require("resend");
const rateLimit = require("express-rate-limit");

const app = express();
const resend = new Resend(process.env.RESEND_API_KEY);

app.use(express.json({ limit: "20kb" }));
app.use(express.static("public"));

const emailLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 5,
  message: {
    error: "Too many messages. Please try again later."
  }
});

app.post("/send-email", emailLimiter, async (req, res) => {
  const { name, email, subject, message } = req.body || {};

  if (
    typeof name !== "string" ||
    typeof email !== "string" ||
    typeof message !== "string" ||
    !name.trim() ||
    !message.trim() ||
    name.length > 80 ||
    email.length > 254 ||
    message.length > 5000 ||
    (subject && (typeof subject !== "string" || subject.length > 150))
  ) {
    return res.status(400).json({
      error: "Please check your details and try again."
    });
  }

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
    return res.status(400).json({
      error: "Please enter a valid email address."
    });
  }

  if (
    !process.env.RESEND_API_KEY ||
    !process.env.CONTACT_EMAIL ||
    !process.env.MAIL_FROM
  ) {
    console.error("Email environment variables are missing.");
    return res.status(500).json({
      error: "Email service is not configured yet."
    });
  }

  try {
    const { data, error } = await resend.emails.send({
      from: process.env.MAIL_FROM,
      to: [process.env.CONTACT_EMAIL],
      replyTo: email.trim(),
      subject: (subject || "New Checkpoint Gaming message").trim(),
      text:
        `Name: ${name.trim()}\n` +
        `Email: ${email.trim()}\n\n` +
        message.trim()
    });

    if (error) {
      console.error("Resend error:", error);
      return res.status(502).json({
        error: "The email service could not send your message."
      });
    }

    return res.json({
      success: true,
      messageId: data?.id
    });
  } catch (error) {
    console.error("Email sending failed:", error);
    return res.status(500).json({
      error: "Something went wrong. Please try again later."
    });
  }
});

app.get("/health", (req, res) => {
  res.json({ status: "ok" });
});

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log(`Checkpoint Gaming is running on port ${PORT}`);
});
