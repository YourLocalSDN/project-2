
const form = document.querySelector("#contact-form");
const status = document.querySelector("#form-status");
const sendButton = document.querySelector("#send-button");

form.addEventListener("submit", async (event) => {
  event.preventDefault();

  status.textContent = "Sending your message...";
  sendButton.disabled = true;

  const formData = new FormData(form);

  const message = {
    name: formData.get("name").trim(),
    email: formData.get("email").trim(),
    subject: formData.get("subject").trim(),
    message: formData.get("message").trim()
  };

  try {
    const response = await fetch("/send-email", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(message)
    });

    const result = await response.json();

    if (!response.ok) {
      throw new Error(result.error || "Email could not be sent.");
    }

    status.textContent = "Message sent successfully!";
    form.reset();
  } catch (error) {
    status.textContent =
      error.message || "Something went wrong. Please try again.";
  } finally {
    sendButton.disabled = false;
  }
});
